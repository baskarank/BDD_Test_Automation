package demo;

import org.openqa.selenium.NoSuchElementException;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

import net.serenitybdd.core.pages.WebElementFacade;

public class FlightListPage extends PageObject {

	@FindBy(xpath = "//tr[1]//td[1]")
	private WebElementFacade btn_ticketDsipalyedFirst;

	@FindBy(xpath = "//input[@id='inputName']")
	private WebElementFacade txt_passengerName;

	@FindBy(xpath = "//input[@id='address']")
	private WebElementFacade txt_address;

	@FindBy(xpath = "//input[@id='city']")
	private WebElementFacade txt_city;

	@FindBy(xpath = "//input[@id='state']")
	private WebElementFacade txt_state;

	@FindBy(xpath = "//input[@id='zipCode']")
	private WebElementFacade txt_zipCode;

	@FindBy(xpath = "//select[@id='cardType']")
	private WebElementFacade dddown_CardType;

	@FindBy(xpath = "//input[@id='creditCardNumber']")
	private WebElementFacade txt_CardNumber;

	@FindBy(xpath = "//input[@id='creditCardMonth']")
	private WebElementFacade txt_CardMonth;

	@FindBy(xpath = "//input[@id='creditCardYear']")
	private WebElementFacade txt_CardYear;

	@FindBy(xpath = "//input[@id='nameOnCard']")
	private WebElementFacade txt_nameOnCard;

	@FindBy(xpath = "//input[@class='btn btn-primary']")
	private WebElementFacade btn_BookTicet;

	public boolean verifyPageTitle() {
		try {
			String pageTitle = getDriver().getTitle();

			if (pageTitle.equalsIgnoreCase("BlazeDemo - reserve")) {
				btn_ticketDsipalyedFirst.click();
				return true;
			} else {
				return false;
			}

		}

		catch (Exception e) {

			return false;

		}

	}

	public boolean fillPassengerDetails() {
		try {			
			txt_passengerName.type("Baskaran");
			txt_address.type("No1 Vivekanda street");
			txt_city.type("Dubai");
			txt_state.type("UAE");
			txt_zipCode.type("4321");
			txt_CardNumber.type("1234 5678 1234 5678");
			txt_CardMonth.type("12");
			txt_CardYear.type("2030");
			btn_BookTicet.click();

			return true;
		}

		catch (NoSuchElementException e) {

			return false;

		}

		catch (Exception e) {

			return false;

		}

	}

}
