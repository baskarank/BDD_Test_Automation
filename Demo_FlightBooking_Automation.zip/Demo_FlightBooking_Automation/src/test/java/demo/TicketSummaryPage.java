package demo;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

import net.serenitybdd.core.pages.WebElementFacade;

public class TicketSummaryPage extends PageObject {

	@FindBy(xpath = "//h1[contains(text(),'Thank you for your purchase today!')]")
	private WebElementFacade txt_BookedMessage;

	public boolean verifyBookingComfirmation() {
		try {
			String pageTitle = getDriver().getTitle();

			if (pageTitle.equalsIgnoreCase("BlazeDemo Confirmation") && txt_BookedMessage.isDisplayed()) {
				return true;
			} else {
				return false;
			}

		}

		catch (Exception e) {

			return false;

		}

	}

}
