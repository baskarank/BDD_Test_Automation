package demo;



import org.junit.Assert;



import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {

	
	FinderPage fp = new FinderPage();
	FlightListPage flp = new FlightListPage();
	TicketSummaryPage tsp = new TicketSummaryPage();

	@Given("^the customer launched the flight booking page$")
	public void theCustomerLauchedTheFlightBookingPage() throws Exception {
		fp.launchApp();
	
	}
	
	@When("^the customer fill the source and destination city$")
	public void fillTheSourceAndDestinationCity() throws Exception {
		Assert.assertTrue(fp.findFlight());
	}
	
	@Then("^the customer should be navigate into Flight details page$")
	public void shouldbenavigateintoFlightdetails_page() throws Exception {

		Assert.assertTrue(flp.verifyPageTitle());

	}
	
	@When("^the customer fill the passenger details and purchase the ticket$")
	public void fillPassengerDetailsAndPurchaseTicket1() throws Exception {
		Assert.assertTrue(flp.fillPassengerDetails());
	}
	

	
	@Then("^the customer should see the booking confirmation message$")
	public void i_should_see_the_select_Flight_page() throws Exception {
		Assert.assertTrue(tsp.verifyBookingComfirmation());
	}

}
