package demo;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

import net.serenitybdd.core.pages.WebElementFacade;

public class FinderPage extends PageObject {

	@FindBy(xpath = "//select[@name='fromPort']")
	private WebElementFacade dddown_fromPort;

	@FindBy(xpath = "//select[@name='toPort']")
	private WebElementFacade dddown_toPort;

	@FindBy(xpath = "//input[@class='btn btn-primary']")
	private WebElementFacade btn_reserveFlight;

	public boolean launchApp() {
		try {
			getDriver().get("http://www.blazedemo.com/");
			
			String pageTitle = getDriver().getTitle();

			if (pageTitle.equalsIgnoreCase("BlazeDemo")) {
				return false;
			} else {
				return false;
			}

		}

		catch (Exception e) {

			return false;

		}

	}
	
	public boolean findFlight() {
		try {
			
			dddown_fromPort.containsSelectOption("Paris");
			dddown_toPort.containsSelectOption("London");
			btn_reserveFlight.click();
			return true;

		}

		catch (Exception e) {

			return false;

		}

	}

}
