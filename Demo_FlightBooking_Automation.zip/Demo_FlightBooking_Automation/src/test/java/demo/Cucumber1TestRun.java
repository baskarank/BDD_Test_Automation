package demo;

import cucumber.api.CucumberOptions;

import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.github.invictum.reportportal.LogsPreset;
import com.github.invictum.reportportal.ReportIntegrationConfig;
import com.github.invictum.reportportal.log.unit.Essentials;
import com.github.invictum.reportportal.log.unit.Selenium;


@RunWith(CucumberWithSerenity.class)
@CucumberOptions(plugin = { "pretty"}, features = "src/test/resources/features/BookTicket.feature")
public class Cucumber1TestRun {
	
	


}
